var searchData=
[
  ['pressed_41',['pressed',['../class_bounce2_1_1_button.html#a61541ae21354cb7f5cc5bc8c05db59dd',1,'Bounce2::Button']]],
  ['previousduration_42',['previousDuration',['../class_debouncer.html#ac6af22dc9c6ae84462fe356b7430659e',1,'Debouncer']]]
];
